//
//  ViewController.swift
//  ToDoList
//
//  Created by Tech on 2017-04-03.
//  Copyright © 2017 Tech. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var lists:[List] = []
    
    
    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getData()
        tableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        // using coredata value in table row
        let list = lists[indexPath.row]
        cell?.textLabel?.text = list.name
        cell?.detailTextLabel?.text = list.date
        
        return cell!
    }
    func getData(){
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        do{
        lists = try context.fetch(List.fetchRequest())
        }
        catch{
        print("fatching error")
        }
        
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        if editingStyle == .delete{
            let list = lists[indexPath.row]
            context.delete(list)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            do{
                lists = try context.fetch(List.fetchRequest())
            }catch{
                print("fetching Error")
            }
        }
        tableView.reloadData()
    }

    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lists.count
    }


}

