//
//  AddListViewController.swift
//  ToDoList
//
//  Created by Tech on 2017-04-03.
//  Copyright © 2017 Tech. All rights reserved.
//

import UIKit

class AddListViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtDate: UITextField!
    
    @IBAction func btnSave(_ sender: UIButton) {
        
        //checking whether enter is impty
        if (txtName.text != "")&&(txtDate.text != ""){
            
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let list = List(context: context)
        
        //putting value in coredata
        
        list.name = txtName.text
        list.date = txtDate.text
            
            // Data saving in coredata
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
        
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
    
    
    @IBAction func btnCancle(_ sender: UIButton) {
        
        dismiss(animated: true, completion: nil)
    }
    
    
    
    
    
    
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == txtDate{
            let datePicker = UIDatePicker()
            textField.inputView = datePicker
            datePicker.addTarget(self, action:#selector(AddListViewController.datePickerChanged(_:)), for: .valueChanged)
        }
        return true
    }
    
    
    func datePickerChanged(_ sender:UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        txtDate.text = formatter.string(from: sender.date)
    }
    
    
    
    // mark : touch event
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true) // method for closesing keyboark or datePiker
    }

    
    
    // mark : Text field delegate methods
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        txtName.delegate = self
        txtDate.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
